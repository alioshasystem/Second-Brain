import { useState } from 'react';
import { ArrowLeft, Check } from 'lucide-react';

interface BlankNoteEditorProps {
  onBack: () => void;
  onSave: (noteData: { title: string; content: string; tags: string[] }) => void;
}

export function BlankNoteEditor({ onBack, onSave }: BlankNoteEditorProps) {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');

  const handleSave = () => {
    if (title.trim() || content.trim()) {
      onSave({
        title: title.trim() || 'Untitled Note',
        content: content.trim(),
        tags: ['Manual'],
      });
      onBack();
    }
  };

  return (
    <div className="flex flex-col h-screen bg-white">
      {/* Header */}
      <div className="border-b px-4 py-3 flex items-center justify-between">
        <button onClick={onBack} className="p-2 hover:bg-gray-100 rounded-lg -ml-2">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <span className="font-medium">New Note</span>
        <button 
          onClick={handleSave}
          className="p-2 hover:bg-gray-100 rounded-lg text-black"
        >
          <Check className="w-5 h-5" />
        </button>
      </div>

      {/* Note Editor */}
      <div className="flex-1 flex flex-col p-6">
        {/* Title Input */}
        <input
          type="text"
          placeholder="Title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="text-2xl font-semibold mb-4 outline-none placeholder:text-gray-400"
          autoFocus
        />

        {/* Content Textarea */}
        <textarea
          placeholder="Start writing..."
          value={content}
          onChange={(e) => setContent(e.target.value)}
          className="flex-1 outline-none resize-none placeholder:text-gray-400"
        />
      </div>
    </div>
  );
}
