import { ArrowLeft, User, Palette, Lock, FileText, Info, MessageSquare, LogOut, ListOrdered } from 'lucide-react';

interface SettingsViewProps {
  onBack: () => void;
  onPrioritizeClick?: () => void;
}

export function SettingsView({ onBack, onPrioritizeClick }: SettingsViewProps) {
  return (
    <div className="flex flex-col h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b px-4 py-4 flex items-center gap-3">
        <button onClick={onBack} className="p-2 hover:bg-gray-100 rounded-full -ml-2">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="text-xl font-semibold">Settings</h1>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-4">
        {/* Pro Upgrade Card */}
        <div className="bg-white rounded-xl p-6 mb-4">
          <h2 className="text-lg font-semibold mb-2">Want more features?</h2>
          <p className="text-gray-600 text-sm mb-4">
            Upgrade to unlock additional features
          </p>
          <button className="bg-black text-white rounded-lg px-6 py-2.5 hover:bg-gray-900 transition-colors">
            Get Pro
          </button>
        </div>

        {/* Settings Options */}
        <div className="bg-white rounded-xl overflow-hidden mb-4">
          {onPrioritizeClick && (
            <button 
              onClick={onPrioritizeClick}
              className="w-full flex items-center gap-3 px-4 py-4 hover:bg-gray-50 transition-colors border-b"
            >
              <ListOrdered className="w-5 h-5" />
              <span>Prioritize Notes</span>
            </button>
          )}
          <button className="w-full flex items-center gap-3 px-4 py-4 hover:bg-gray-50 transition-colors border-b">
            <User className="w-5 h-5" />
            <span>Account</span>
          </button>
          <button className="w-full flex items-center gap-3 px-4 py-4 hover:bg-gray-50 transition-colors border-b">
            <Palette className="w-5 h-5" />
            <span>Personalize</span>
          </button>
          <button className="w-full flex items-center gap-3 px-4 py-4 hover:bg-gray-50 transition-colors border-b">
            <Lock className="w-5 h-5" />
            <span>Privacy</span>
          </button>
          <button className="w-full flex items-center gap-3 px-4 py-4 hover:bg-gray-50 transition-colors border-b">
            <FileText className="w-5 h-5" />
            <span>Terms of Services</span>
          </button>
          <button className="w-full flex items-center gap-3 px-4 py-4 hover:bg-gray-50 transition-colors">
            <Info className="w-5 h-5" />
            <span>About</span>
          </button>
        </div>

        {/* Additional Options */}
        <div className="bg-white rounded-xl overflow-hidden">
          <button className="w-full flex items-center gap-3 px-4 py-4 hover:bg-gray-50 transition-colors border-b">
            <MessageSquare className="w-5 h-5" />
            <span>Feedback</span>
          </button>
          <button className="w-full flex items-center gap-3 px-4 py-4 hover:bg-gray-50 transition-colors">
            <LogOut className="w-5 h-5" />
            <span>Sign out</span>
          </button>
        </div>
      </div>
    </div>
  );
}