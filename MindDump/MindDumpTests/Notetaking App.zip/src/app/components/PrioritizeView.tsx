import { useState, useRef, useEffect } from 'react';
import { ArrowLeft, X, Heart } from 'lucide-react';
import { Note } from './NotesListView';
import { Badge } from './ui/badge';

interface PrioritizeViewProps {
  notes: Note[];
  onBack: () => void;
  onUpdatePriority: (noteId: string, priority: number) => void;
}

export function PrioritizeView({ notes, onBack, onUpdatePriority }: PrioritizeViewProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [swipedNotes, setSwipedNotes] = useState<Set<string>>(new Set());
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const startPos = useRef({ x: 0, y: 0 });

  // Filter out notes that have been swiped in this session
  const availableNotes = notes.filter(note => !swipedNotes.has(note.id));
  const currentNote = availableNotes[currentIndex];

  const handleTouchStart = (e: React.TouchEvent) => {
    setIsDragging(true);
    startPos.current = {
      x: e.touches[0].clientX,
      y: e.touches[0].clientY
    };
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isDragging) return;

    const deltaX = e.touches[0].clientX - startPos.current.x;
    const deltaY = e.touches[0].clientY - startPos.current.y;

    setDragOffset({ x: deltaX, y: deltaY });
  };

  const handleTouchEnd = () => {
    if (!currentNote) return;

    const swipeThreshold = 100;

    if (dragOffset.x > swipeThreshold) {
      // Swipe right - prioritize
      handlePrioritize();
    } else if (dragOffset.x < -swipeThreshold) {
      // Swipe left - ignore
      handleIgnore();
    }

    setDragOffset({ x: 0, y: 0 });
    setIsDragging(false);
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    startPos.current = {
      x: e.clientX,
      y: e.clientY
    };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;

    const deltaX = e.clientX - startPos.current.x;
    const deltaY = e.clientY - startPos.current.y;

    setDragOffset({ x: deltaX, y: deltaY });
  };

  const handleMouseUp = () => {
    if (!currentNote) return;

    const swipeThreshold = 100;

    if (dragOffset.x > swipeThreshold) {
      // Swipe right - prioritize
      handlePrioritize();
    } else if (dragOffset.x < -swipeThreshold) {
      // Swipe left - ignore
      handleIgnore();
    }

    setDragOffset({ x: 0, y: 0 });
    setIsDragging(false);
  };

  const handlePrioritize = () => {
    if (!currentNote) return;

    const currentPriority = currentNote.priority || 0;
    const newPriority = Math.min(currentPriority + 1, 4);
    
    onUpdatePriority(currentNote.id, newPriority);
    setSwipedNotes(prev => new Set([...prev, currentNote.id]));
    
    // Move to next note
    if (currentIndex < availableNotes.length - 1) {
      setCurrentIndex(currentIndex + 1);
    } else {
      setCurrentIndex(0);
    }
  };

  const handleIgnore = () => {
    if (!currentNote) return;

    setSwipedNotes(prev => new Set([...prev, currentNote.id]));
    
    // Move to next note
    if (currentIndex < availableNotes.length - 1) {
      setCurrentIndex(currentIndex + 1);
    } else {
      setCurrentIndex(0);
    }
  };

  const getPriorityColor = (priority: number = 0) => {
    switch (priority) {
      case 1:
        return 'bg-blue-200 border-blue-300';
      case 2:
        return 'bg-blue-500 border-blue-600 text-white';
      case 3:
        return 'bg-purple-600 border-purple-700 text-white';
      case 4:
        return 'bg-black border-black text-white';
      default:
        return 'bg-white border-gray-200';
    }
  };

  const getPriorityLabel = (priority: number = 0) => {
    switch (priority) {
      case 1:
        return 'Low Priority';
      case 2:
        return 'Medium Priority';
      case 3:
        return 'High Priority';
      case 4:
        return 'Critical Priority';
      default:
        return 'No Priority';
    }
  };

  const rotation = dragOffset.x * 0.05;
  const opacity = Math.max(0.5, 1 - Math.abs(dragOffset.x) / 300);

  return (
    <div className="flex flex-col h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b px-4 py-3 flex items-center justify-between">
        <button onClick={onBack} className="p-2 hover:bg-gray-100 rounded-lg -ml-2">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <span className="font-medium">Prioritize Notes</span>
        <div className="w-9" /> {/* Spacer for alignment */}
      </div>

      {/* Content */}
      <div className="flex-1 flex flex-col items-center justify-center p-4 relative">
        {availableNotes.length === 0 ? (
          <div className="text-center">
            <p className="text-gray-500 text-lg mb-4">All notes have been prioritized!</p>
            <button
              onClick={onBack}
              className="px-6 py-3 bg-black text-white rounded-lg hover:bg-gray-800 transition-colors"
            >
              Back to Notes
            </button>
          </div>
        ) : (
          <>
            {/* Progress indicator */}
            <div className="absolute top-4 left-0 right-0 px-8">
              <div className="flex items-center justify-center gap-2 mb-2">
                <span className="text-sm text-gray-600">
                  {swipedNotes.size} / {notes.length} reviewed
                </span>
              </div>
              <div className="w-full h-1 bg-gray-200 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-black transition-all duration-300"
                  style={{ width: `${(swipedNotes.size / notes.length) * 100}%` }}
                />
              </div>
            </div>

            {/* Swipeable Card */}
            <div
              className="w-full max-w-md select-none cursor-grab active:cursor-grabbing"
              style={{
                transform: `translateX(${dragOffset.x}px) translateY(${dragOffset.y}px) rotate(${rotation}deg)`,
                opacity,
                transition: isDragging ? 'none' : 'transform 0.3s ease, opacity 0.3s ease',
              }}
              onTouchStart={handleTouchStart}
              onTouchMove={handleTouchMove}
              onTouchEnd={handleTouchEnd}
              onMouseDown={handleMouseDown}
              onMouseMove={handleMouseMove}
              onMouseUp={handleMouseUp}
              onMouseLeave={() => {
                if (isDragging) {
                  handleMouseUp();
                }
              }}
            >
              <div className={`rounded-2xl border-2 shadow-xl p-8 ${getPriorityColor(currentNote?.priority)}`}
                   style={{ minHeight: '400px' }}>
                
                {/* Priority Badge */}
                {currentNote && currentNote.priority !== undefined && currentNote.priority > 0 && (
                  <div className="mb-4">
                    <Badge variant="secondary" className="text-xs">
                      {getPriorityLabel(currentNote.priority)}
                    </Badge>
                  </div>
                )}

                {/* Date */}
                <div className="text-sm font-medium mb-3 opacity-70">
                  {currentNote?.date}
                </div>

                {/* Title */}
                <h2 className="text-3xl font-bold mb-4">
                  {currentNote?.title}
                </h2>

                {/* Tags */}
                {currentNote?.tags && currentNote.tags.length > 0 && (
                  <div className="flex flex-wrap gap-2 mb-4">
                    {currentNote.tags.map((tag, idx) => (
                      <Badge key={idx} variant="outline" className="text-sm">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                )}

                {/* Preview */}
                {currentNote?.preview && (
                  <p className="text-base leading-relaxed opacity-80">
                    {currentNote.preview}
                  </p>
                )}
              </div>
            </div>

            {/* Swipe Indicators */}
            {isDragging && (
              <>
                {dragOffset.x > 50 && (
                  <div className="absolute top-1/2 right-8 -translate-y-1/2 bg-green-500 text-white px-6 py-3 rounded-full font-bold text-lg transform rotate-12 shadow-lg">
                    PRIORITIZE
                  </div>
                )}
                {dragOffset.x < -50 && (
                  <div className="absolute top-1/2 left-8 -translate-y-1/2 bg-red-500 text-white px-6 py-3 rounded-full font-bold text-lg transform -rotate-12 shadow-lg">
                    IGNORE
                  </div>
                )}
              </>
            )}

            {/* Action Buttons */}
            <div className="flex items-center justify-center gap-8 mt-8">
              <button
                onClick={handleIgnore}
                className="w-16 h-16 bg-white rounded-full shadow-lg hover:shadow-xl transition-all hover:scale-110 flex items-center justify-center border-2 border-red-200 hover:border-red-400"
              >
                <X className="w-8 h-8 text-red-500" />
              </button>

              <button
                onClick={handlePrioritize}
                className="w-16 h-16 bg-white rounded-full shadow-lg hover:shadow-xl transition-all hover:scale-110 flex items-center justify-center border-2 border-green-200 hover:border-green-400"
              >
                <Heart className="w-8 h-8 text-green-500" />
              </button>
            </div>

            {/* Instructions */}
            <div className="mt-8 text-center text-sm text-gray-500">
              <p>Swipe right to prioritize • Swipe left to ignore</p>
              <p className="mt-1">Priority levels: Light Blue → Blue → Purple → Black</p>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
