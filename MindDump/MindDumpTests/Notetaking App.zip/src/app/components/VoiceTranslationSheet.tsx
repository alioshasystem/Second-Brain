import { Mic, MicOff, X } from 'lucide-react';
import { useState } from 'react';

interface VoiceTranslationSheetProps {
  open: boolean;
  onClose: () => void;
  onSaveTranscription: (text: string) => void;
}

export function VoiceTranslationSheet({ open, onClose, onSaveTranscription }: VoiceTranslationSheetProps) {
  const [isRecording, setIsRecording] = useState(false);
  const [transcription, setTranscription] = useState('');

  const handleStartRecording = () => {
    setIsRecording(true);
    // Mock transcription for demo
    setTimeout(() => {
      setTranscription('This is a sample transcription of your voice...');
    }, 2000);
  };

  const handleStopRecording = () => {
    setIsRecording(false);
  };

  const handleSave = () => {
    if (transcription.trim()) {
      onSaveTranscription(transcription);
      setTranscription('');
      setIsRecording(false);
      onClose();
    }
  };

  if (!open) return null;

  return (
    <>
      {/* Overlay */}
      <div 
        className="fixed inset-0 bg-black/50 z-40"
        onClick={onClose}
      />
      
      {/* Bottom Sheet */}
      <div className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-white rounded-t-3xl z-50 shadow-2xl animate-in slide-in-from-bottom duration-300">
        <div className="p-6">
          {/* Handle Bar */}
          <div className="w-12 h-1 bg-gray-300 rounded-full mx-auto mb-6" />
          
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold">Voice to Text</h2>
            <button 
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-full"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Recording Status */}
          <div className="text-center mb-6">
            {isRecording ? (
              <div className="flex flex-col items-center gap-3">
                <div className="w-20 h-20 bg-red-100 rounded-full flex items-center justify-center animate-pulse">
                  <Mic className="w-10 h-10 text-red-600" />
                </div>
                <p className="text-sm text-gray-600">Recording...</p>
              </div>
            ) : (
              <div className="flex flex-col items-center gap-3">
                <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center">
                  <MicOff className="w-10 h-10 text-gray-400" />
                </div>
                <p className="text-sm text-gray-600">Tap to start recording</p>
              </div>
            )}
          </div>

          {/* Transcription Display */}
          {transcription && (
            <div className="bg-gray-50 rounded-lg p-4 mb-4 min-h-24 max-h-48 overflow-y-auto">
              <p className="text-sm text-gray-700">{transcription}</p>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex gap-3">
            {!isRecording ? (
              <button
                onClick={handleStartRecording}
                className="flex-1 bg-black text-white rounded-lg py-3 flex items-center justify-center gap-2 hover:bg-gray-900 transition-colors"
              >
                <Mic className="w-5 h-5" />
                Start Recording
              </button>
            ) : (
              <button
                onClick={handleStopRecording}
                className="flex-1 bg-red-600 text-white rounded-lg py-3 flex items-center justify-center gap-2 hover:bg-red-700 transition-colors"
              >
                <MicOff className="w-5 h-5" />
                Stop Recording
              </button>
            )}
            
            {transcription && !isRecording && (
              <button
                onClick={handleSave}
                className="flex-1 bg-blue-600 text-white rounded-lg py-3 hover:bg-blue-700 transition-colors"
              >
                Save as Note
              </button>
            )}
          </div>

          {/* Helper Text */}
          <p className="text-xs text-gray-500 text-center mt-4">
            Speak clearly for better transcription accuracy
          </p>
        </div>
      </div>
    </>
  );
}
