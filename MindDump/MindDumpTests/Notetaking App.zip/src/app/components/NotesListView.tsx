import { Search, MoreVertical, Plus, Settings, ChevronDown } from 'lucide-react';
import { Badge } from './ui/badge';
import { SwipeableNoteCard } from './SwipeableNoteCard';

export interface Note {
  id: string;
  title: string;
  date: string;
  tags?: string[];
  preview?: string;
  content?: string;
  category?: string;
  subCategory?: string;
  createdBy?: string;
  lastModified?: string;
  promoted?: boolean;
  priority?: number; // 0-4: 0=default, 1=light blue, 2=blue, 3=purple, 4=black
}

interface NotesListViewProps {
  notes: Note[];
  onNoteClick: (note: Note) => void;
  onAddNote: () => void;
  onSettingsClick: () => void;
  selectedTag: string | null;
  onTitleClick: () => void;
  onTogglePromote: (noteId: string) => void;
}

export function NotesListView({ notes, onNoteClick, onAddNote, onSettingsClick, selectedTag, onTitleClick, onTogglePromote }: NotesListViewProps) {
  return (
    <div className="flex flex-col h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b px-4 py-3 flex items-center justify-between">
        <button onClick={onTitleClick} className="hover:bg-gray-50 px-2 py-1 rounded-lg transition-colors flex items-center gap-2">
          <h1 className="text-xl font-semibold">{selectedTag || 'All Notes'}</h1>
          <ChevronDown className="w-5 h-5 text-gray-500" />
        </button>
        <div className="flex items-center gap-2">
          <button className="p-2 hover:bg-gray-100 rounded-lg">
            <Search className="w-5 h-5" />
          </button>
          <button onClick={onSettingsClick} className="p-2 hover:bg-gray-100 rounded-lg">
            <Settings className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Notes List */}
      <div className="flex-1 overflow-y-auto px-4 py-4 pb-24">
        {notes.map((note) => (
          <SwipeableNoteCard
            key={note.id}
            note={note}
            onClick={onNoteClick}
            onTogglePromote={onTogglePromote}
          />
        ))}
      </div>
    </div>
  );
}