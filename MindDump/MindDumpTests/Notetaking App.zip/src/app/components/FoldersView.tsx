import { FileText, CheckSquare, PenLine, Briefcase, BookOpen, Plus, Search, Settings } from 'lucide-react';

export interface Folder {
  id: string;
  name: string;
  icon: string;
  count?: number;
}

interface FoldersViewProps {
  onAddFolder: () => void;
  activeTab: 'notes' | 'actions';
  onTabChange: (tab: 'notes' | 'actions') => void;
  onSettingsClick: () => void;
}

export function FoldersView({ onAddFolder, activeTab, onTabChange, onSettingsClick }: FoldersViewProps) {
  const folders: Folder[] = [
    { id: '1', name: 'My Notes', icon: 'notes' },
    { id: '2', name: 'To-do list', icon: 'todo' },
    { id: '3', name: 'Journal', icon: 'journal' },
    { id: '4', name: 'Projects', icon: 'projects' },
    { id: '5', name: 'Reading List', icon: 'reading' },
  ];

  const getIcon = (iconType: string) => {
    switch (iconType) {
      case 'notes':
        return <FileText className="w-8 h-8" />;
      case 'todo':
        return <CheckSquare className="w-8 h-8" />;
      case 'journal':
        return <PenLine className="w-8 h-8" />;
      case 'projects':
        return <Briefcase className="w-8 h-8" />;
      case 'reading':
        return <BookOpen className="w-8 h-8" />;
      default:
        return <FileText className="w-8 h-8" />;
    }
  };

  return (
    <div className="flex flex-col h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b px-4 py-3 flex items-center justify-between">
        <h1 className="text-xl font-semibold">Actions</h1>
        <div className="flex items-center gap-2">
          <button className="p-2 hover:bg-gray-100 rounded-lg">
            <Search className="w-5 h-5" />
          </button>
          <button onClick={onSettingsClick} className="p-2 hover:bg-gray-100 rounded-lg">
            <Settings className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white border-b">
        <div className="flex px-4">
          <button 
            onClick={() => onTabChange('notes')}
            className={`px-4 py-3 border-b-2 ${activeTab === 'notes' ? 'border-black font-medium' : 'border-transparent text-gray-500'}`}
          >
            All Notes
          </button>
          <button 
            onClick={() => onTabChange('actions')}
            className={`px-4 py-3 border-b-2 ${activeTab === 'actions' ? 'border-black font-medium' : 'border-transparent text-gray-500'}`}
          >
            Actions
          </button>
        </div>
      </div>

      {/* Folders Grid */}
      <div className="flex-1 overflow-y-auto p-4 pb-24">
        <div className="grid grid-cols-2 gap-4">
          {folders.map((folder) => (
            <div
              key={folder.id}
              className="bg-white rounded-xl p-6 flex flex-col items-center justify-center cursor-pointer hover:shadow-md transition-shadow aspect-square"
            >
              <div className="mb-3">{getIcon(folder.icon)}</div>
              <div className="font-medium text-center">{folder.name}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}