import { X } from 'lucide-react';
import { Badge } from './ui/badge';

interface TagsDrawerProps {
  open: boolean;
  onClose: () => void;
  tags: string[];
  selectedTag: string | null;
  onTagSelect: (tag: string | null) => void;
}

export function TagsDrawer({ open, onClose, tags, selectedTag, onTagSelect }: TagsDrawerProps) {
  if (!open) return null;

  const handleTagClick = (tag: string | null) => {
    onTagSelect(tag);
    onClose();
  };

  return (
    <>
      {/* Overlay */}
      <div 
        className="fixed inset-0 bg-black/50 z-40"
        onClick={onClose}
      />
      
      {/* Bottom Drawer */}
      <div className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-white rounded-t-3xl z-50 shadow-2xl animate-in slide-in-from-bottom duration-300">
        <div className="p-6">
          {/* Handle Bar */}
          <div className="w-12 h-1 bg-gray-300 rounded-full mx-auto mb-6" />
          
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold">Filter by Tag</h2>
            <button 
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-full"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Tags List */}
          <div className="space-y-2 max-h-96 overflow-y-auto">
            {/* All Notes Option */}
            <button
              onClick={() => handleTagClick(null)}
              className={`w-full text-left px-4 py-3 rounded-lg transition-colors ${
                selectedTag === null
                  ? 'bg-black text-white'
                  : 'bg-gray-50 hover:bg-gray-100'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-medium">All Notes</span>
                {selectedTag === null && (
                  <div className="w-2 h-2 bg-white rounded-full" />
                )}
              </div>
            </button>

            {/* Individual Tags */}
            {tags.map((tag) => (
              <button
                key={tag}
                onClick={() => handleTagClick(tag)}
                className={`w-full text-left px-4 py-3 rounded-lg transition-colors ${
                  selectedTag === tag
                    ? 'bg-black text-white'
                    : 'bg-gray-50 hover:bg-gray-100'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-medium">{tag}</span>
                  {selectedTag === tag && (
                    <div className="w-2 h-2 bg-white rounded-full" />
                  )}
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}
