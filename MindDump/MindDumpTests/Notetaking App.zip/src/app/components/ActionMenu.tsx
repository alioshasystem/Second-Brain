import { Mic, Camera, PenLine, X, Link } from 'lucide-react';

interface ActionMenuProps {
  open: boolean;
  onClose: () => void;
  onDictate: () => void;
  onScan: () => void;
  onWrite: () => void;
  isRecording: boolean;
}

export function ActionMenu({ open, onClose, onDictate, onScan, onWrite, isRecording }: ActionMenuProps) {
  if (!open) return null;

  return (
    <>
      {/* Overlay */}
      <div 
        className="fixed inset-0 bg-black/50 z-40"
        onClick={onClose}
      />
      
      {/* Floating Action Menu */}
      <div className="fixed bottom-24 right-6 z-50 flex flex-col gap-3 items-end animate-in fade-in slide-in-from-bottom-4 duration-300">
        {/* Dictate Button */}
        <div className="flex items-center gap-3">
          <span className="bg-black text-white px-3 py-1 rounded-full text-sm font-medium">
            Transcribe
          </span>
          <button
            onClick={onDictate}
            className={`w-14 h-14 rounded-full shadow-lg hover:shadow-xl transition-all hover:scale-110 flex items-center justify-center ${
              isRecording 
                ? 'bg-red-500 text-white animate-pulse' 
                : 'bg-white text-black'
            }`}
          >
            <Link className="w-6 h-6" />
          </button>
        </div>
        {/* Dictate Button */}
        <div className="flex items-center gap-3">
          <span className="bg-black text-white px-3 py-1 rounded-full text-sm font-medium">
            Dictate
          </span>
          <button
            onClick={onDictate}
            className={`w-14 h-14 rounded-full shadow-lg hover:shadow-xl transition-all hover:scale-110 flex items-center justify-center ${
              isRecording 
                ? 'bg-red-500 text-white animate-pulse' 
                : 'bg-white text-black'
            }`}
          >
            <Mic className="w-6 h-6" />
          </button>
        </div>

        {/* Scan Button */}
        <div className="flex items-center gap-3">
          <span className="bg-black text-white px-3 py-1 rounded-full text-sm font-medium">
            Scan
          </span>
          <button
            onClick={onScan}
            className="w-14 h-14 bg-white text-black rounded-full shadow-lg hover:shadow-xl transition-all hover:scale-110 flex items-center justify-center"
          >
            <Camera className="w-6 h-6" />
          </button>
        </div>

        {/* Write Button */}
        <div className="flex items-center gap-3">
          <span className="bg-black text-white px-3 py-1 rounded-full text-sm font-medium">
            Write
          </span>
          <button
            onClick={onWrite}
            className="w-14 h-14 bg-white text-black rounded-full shadow-lg hover:shadow-xl transition-all hover:scale-110 flex items-center justify-center"
          >
            <PenLine className="w-6 h-6" />
          </button>
        </div>
      </div>

      {/* Close Button (X replaces the Plus) */}
      <button
        onClick={onClose}
        className="fixed bottom-6 right-6 z-50 w-14 h-14 bg-black text-white rounded-full shadow-lg hover:shadow-xl transition-all hover:scale-110 flex items-center justify-center"
      >
        <X className="w-6 h-6" />
      </button>
    </>
  );
}
