import { useState } from 'react';
import { Mic, X } from 'lucide-react';

interface DictateSheetProps {
  open: boolean;
  onClose: () => void;
  onSaveTranscription: (text: string) => void;
}

export function DictateSheet({ open, onClose, onSaveTranscription }: DictateSheetProps) {
  const [isRecording, setIsRecording] = useState(false);
  const [transcription, setTranscription] = useState('');

  if (!open) return null;

  const handleStartRecording = () => {
    setIsRecording(true);
    // Simulate recording - in a real app, this would use the Web Speech API
    setTimeout(() => {
      setIsRecording(false);
      const mockTranscription = "This is a sample transcription from voice recording. In a real implementation, this would capture actual speech input.";
      setTranscription(mockTranscription);
    }, 3000);
  };

  const handleSave = () => {
    if (transcription) {
      onSaveTranscription(transcription);
      setTranscription('');
      onClose();
    }
  };

  const handleClose = () => {
    setTranscription('');
    setIsRecording(false);
    onClose();
  };

  return (
    <>
      {/* Overlay */}
      <div 
        className="fixed inset-0 bg-black/50 z-40"
        onClick={handleClose}
      />
      
      {/* Bottom Sheet */}
      <div className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-white rounded-t-3xl z-50 shadow-2xl animate-in slide-in-from-bottom duration-300">
        <div className="p-6">
          {/* Handle Bar */}
          <div className="w-12 h-1 bg-gray-300 rounded-full mx-auto mb-6" />
          
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold">Voice Dictation</h2>
            <button 
              onClick={handleClose}
              className="p-2 hover:bg-gray-100 rounded-full"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Recording Interface */}
          <div className="space-y-6 mb-6">
            {/* Microphone Button */}
            <div className="flex flex-col items-center gap-4">
              <button
                onClick={handleStartRecording}
                disabled={isRecording}
                className={`w-20 h-20 rounded-full flex items-center justify-center transition-all ${
                  isRecording
                    ? 'bg-red-500 text-white animate-pulse'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                <Mic className="w-10 h-10" />
              </button>
              <p className="text-sm text-gray-600">
                {isRecording ? 'Recording...' : 'Tap to start recording'}
              </p>
            </div>

            {/* Transcription Display */}
            {transcription && (
              <div className="bg-gray-50 rounded-lg p-4 min-h-32">
                <p className="text-gray-800">{transcription}</p>
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3">
            <button
              onClick={handleClose}
              className="flex-1 px-4 py-3 border border-gray-300 rounded-lg font-medium hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              onClick={handleSave}
              disabled={!transcription}
              className="flex-1 px-4 py-3 bg-black text-white rounded-lg font-medium hover:bg-gray-800 disabled:bg-gray-300 disabled:cursor-not-allowed"
            >
              Save Note
            </button>
          </div>
        </div>
      </div>
    </>
  );
}
