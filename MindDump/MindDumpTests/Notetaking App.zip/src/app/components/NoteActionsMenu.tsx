import { CheckSquare, Search, Bell, X, Eye } from 'lucide-react';

interface NoteActionsMenuProps {
  open: boolean;
  onClose: () => void;
  onShowOriginal?: () => void;
  onMakeTodos: () => void;
  onFindRelated: () => void;
  onRemindUser: () => void;
}

export function NoteActionsMenu({ open, onClose, onShowOriginal, onMakeTodos, onFindRelated, onRemindUser }: NoteActionsMenuProps) {
  if (!open) return null;

  return (
    <>
      {/* Overlay */}
      <div 
        className="fixed inset-0 bg-black/50 z-40"
        onClick={onClose}
      />
      
      {/* Floating Action Menu */}
      <div className="fixed bottom-24 right-6 z-50 flex flex-col gap-3 items-end animate-in fade-in slide-in-from-bottom-4 duration-300">
        
        {/* Show original */}
        {onShowOriginal && (
          <div className="flex items-center gap-3">
            <span className="bg-black text-white px-3 py-1 rounded-full text-sm font-medium whitespace-nowrap">
              Show Original
            </span>
            <button
              onClick={onShowOriginal}
              className="w-14 h-14 bg-white text-black rounded-full shadow-lg hover:shadow-xl transition-all hover:scale-110 flex items-center justify-center"
            >
              <Eye className="w-6 h-6" />
            </button>
          </div>
        )}
        
        {/* Make To-Do's */}
        <div className="flex items-center gap-3">
          <span className="bg-black text-white px-3 py-1 rounded-full text-sm font-medium whitespace-nowrap">
            Make To-Do's
          </span>
          <button
            onClick={onMakeTodos}
            className="w-14 h-14 bg-white text-black rounded-full shadow-lg hover:shadow-xl transition-all hover:scale-110 flex items-center justify-center"
          >
            <CheckSquare className="w-6 h-6" />
          </button>
        </div>

        {/* Find Related Notes */}
        <div className="flex items-center gap-3">
          <span className="bg-black text-white px-3 py-1 rounded-full text-sm font-medium whitespace-nowrap">
            Find Related Notes
          </span>
          <button
            onClick={onFindRelated}
            className="w-14 h-14 bg-white text-black rounded-full shadow-lg hover:shadow-xl transition-all hover:scale-110 flex items-center justify-center"
          >
            <Search className="w-6 h-6" />
          </button>
        </div>

        {/* Remind User */}
        <div className="flex items-center gap-3">
          <span className="bg-black text-white px-3 py-1 rounded-full text-sm font-medium whitespace-nowrap">
            Remind Me
          </span>
          <button
            onClick={onRemindUser}
            className="w-14 h-14 bg-white text-black rounded-full shadow-lg hover:shadow-xl transition-all hover:scale-110 flex items-center justify-center"
          >
            <Bell className="w-6 h-6" />
          </button>
        </div>
      </div>

      {/* Close Button (X replaces the Network icon) */}
      <button
        onClick={onClose}
        className="fixed bottom-6 right-6 z-50 w-14 h-14 bg-black text-white rounded-full shadow-lg hover:shadow-xl transition-all hover:scale-110 flex items-center justify-center"
      >
        <X className="w-6 h-6" />
      </button>
    </>
  );
}