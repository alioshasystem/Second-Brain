import { useState, useRef, TouchEvent } from 'react';
import { ArrowUp } from 'lucide-react';
import { Badge } from './ui/badge';
import { Note } from './NotesListView';

interface SwipeableNoteCardProps {
  note: Note;
  onClick: (note: Note) => void;
  onTogglePromote: (noteId: string) => void;
}

export function SwipeableNoteCard({ note, onClick, onTogglePromote }: SwipeableNoteCardProps) {
  const [startX, setStartX] = useState(0);
  const [currentX, setCurrentX] = useState(0);
  const [isSwiping, setIsSwiping] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);

  const handleTouchStart = (e: TouchEvent) => {
    setStartX(e.touches[0].clientX);
    setIsSwiping(true);
  };

  const handleTouchMove = (e: TouchEvent) => {
    if (!isSwiping) return;
    setCurrentX(e.touches[0].clientX);
  };

  const handleTouchEnd = () => {
    const swipeDistance = currentX - startX;
    const threshold = 80; // Minimum swipe distance to trigger action

    if (Math.abs(swipeDistance) > threshold) {
      // Swipe detected - toggle promote status
      onTogglePromote(note.id);
    }

    // Reset
    setIsSwiping(false);
    setStartX(0);
    setCurrentX(0);
  };

  const handleClick = () => {
    if (!isSwiping) {
      onClick(note);
    }
  };

  const swipeDistance = isSwiping ? currentX - startX : 0;
  const opacity = isSwiping ? Math.max(0.5, 1 - Math.abs(swipeDistance) / 200) : 1;

  return (
    <div
      ref={cardRef}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      onClick={handleClick}
      className="bg-white rounded-xl p-4 mb-3 cursor-pointer hover:shadow-md transition-all relative"
      style={{
        transform: isSwiping ? `translateX(${swipeDistance}px)` : 'translateX(0)',
        opacity: opacity,
        transition: isSwiping ? 'none' : 'transform 0.2s ease-out, opacity 0.2s ease-out',
      }}
    >
      {/* Promoted Icon */}
      {note.promoted && (
        <div className="absolute top-3 right-3">
          <div className="bg-black text-white p-1.5 rounded-full">
            <ArrowUp className="w-4 h-4" />
          </div>
        </div>
      )}

      <div className="text-xs text-gray-500 mb-1">{note.date}</div>
      <h3 className="font-semibold mb-2 pr-8">{note.title}</h3>
      {note.tags && note.tags.length > 0 && (
        <div className="flex flex-wrap gap-1.5 mb-2">
          {note.tags.map((tag, idx) => (
            <Badge key={idx} variant="secondary" className="text-xs">
              {tag}
            </Badge>
          ))}
        </div>
      )}
      {note.preview && (
        <p className="text-sm text-gray-600 line-clamp-3">{note.preview}</p>
      )}
    </div>
  );
}
