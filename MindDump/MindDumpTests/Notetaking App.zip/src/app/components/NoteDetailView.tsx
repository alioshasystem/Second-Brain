import { ArrowLeft, Search, MoreVertical, ChevronRight, Settings, Origami, ArrowUp } from 'lucide-react';
import { Badge } from './ui/badge';
import { Note } from './NotesListView';
import { useState } from 'react';
import { NoteActionsMenu } from './NoteActionsMenu';

interface NoteDetailViewProps {
  note: Note;
  onBack: () => void;
  onSettingsClick: () => void;
  onTogglePromote: (noteId: string) => void;
}

export function NoteDetailView({ note, onBack, onSettingsClick, onTogglePromote }: NoteDetailViewProps) {
  const [showActionsMenu, setShowActionsMenu] = useState(false);

  const handleShowOriginal = () => {
    setShowActionsMenu(false);
    // TODO: Implement make show original note functionality
    alert('Showing original note...');
  };
  
  const handleMakeTodos = () => {
    setShowActionsMenu(false);
    // TODO: Implement make to-dos functionality
    alert('Converting note to to-do items...');
  };

  const handleFindRelated = () => {
    setShowActionsMenu(false);
    // TODO: Implement find related notes
    alert('Finding related notes...');
  };

  const handleRemindUser = () => {
    setShowActionsMenu(false);
    // TODO: Implement reminder functionality
    alert('Setting up reminder...');
  };

  return (
    <div className="flex flex-col h-screen bg-white">
      {/* Header */}
      <div className="border-b px-4 py-3 flex items-center justify-between">
        <button onClick={onBack} className="p-2 hover:bg-gray-100 rounded-lg -ml-2">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <span className="font-medium">All Notes</span>
        <div className="flex items-center gap-2">
          <button className="p-2 hover:bg-gray-100 rounded-lg">
            <Search className="w-5 h-5" />
          </button>
          <button onClick={onSettingsClick} className="p-2 hover:bg-gray-100 rounded-lg">
            <Settings className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto px-4 py-6 pb-24">
        {/* Title with Promote Button */}
        <div className="flex items-start justify-between mb-4">
          <h1 className="text-2xl font-bold flex-1">{note.title}</h1>
          <button
            onClick={() => onTogglePromote(note.id)}
            className={`flex-shrink-0 w-10 h-10 rounded-full border-2 flex items-center justify-center transition-all ${
              note.promoted
                ? 'bg-black border-black text-white'
                : 'bg-white border-gray-300 text-gray-700 hover:border-gray-400'
            }`}
          >
            <ArrowUp className="w-5 h-5" />
          </button>
        </div>

        {/* Meta Info */}
        <div className="mb-4">
          {note.lastModified && (
            <div className="text-sm text-gray-500 mb-2">
              Last Modified: {note.lastModified}
            </div>
          )}
        </div>

        {/* Tags */}
        {note.tags && note.tags.length > 0 && (
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-sm text-gray-500">Tags:</span>
              <div className="flex items-center gap-1.5 flex-wrap">
                {note.tags.map((tag, idx) => (
                  <Badge key={idx} variant="secondary" className="text-xs">
                    {tag}
                  </Badge>
                ))}
                <button className="p-1 hover:bg-gray-100 rounded">
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Note Content */}
        {note.content && (
          <div className="prose prose-sm max-w-none">
            {note.content.split('\\n\\n').map((paragraph, idx) => (
              <p key={idx} className="mb-4 text-gray-700 leading-relaxed">
                {paragraph}
              </p>
            ))}
          </div>
        )}
      </div>

      {/* Floating Connect Button */}
      {!showActionsMenu && (
        <button
          onClick={() => setShowActionsMenu(true)}
          className="fixed bottom-6 right-6 z-50 w-14 h-14 bg-black text-white rounded-full shadow-lg hover:shadow-xl transition-all hover:scale-110 flex items-center justify-center"
        >
          <Origami className="w-6 h-6" />
        </button>
      )}

      {/* Note Actions Menu */}
      <NoteActionsMenu
        open={showActionsMenu}
        onClose={() => setShowActionsMenu(false)}
        onShowOriginal={handleShowOriginal}
        onMakeTodos={handleMakeTodos}
        onFindRelated={handleFindRelated}
        onRemindUser={handleRemindUser}
      />
    </div>
  );
}