import { useState } from 'react';
import { NotesListView, Note } from './components/NotesListView';
import { NoteDetailView } from './components/NoteDetailView';
import { SettingsView } from './components/SettingsView';
import { AddNoteDialog } from './components/AddNoteDialog';
import { VoiceTranslationSheet } from './components/VoiceTranslationSheet';
import { TagsDrawer } from './components/TagsDrawer';
import { ActionMenu } from './components/ActionMenu';
import { DictateSheet } from './components/DictateSheet';
import { BlankNoteEditor } from './components/BlankNoteEditor';
import { PrioritizeView } from './components/PrioritizeView';
import { Settings, Plus } from 'lucide-react';

type View = 'notes' | 'note-detail' | 'settings' | 'blank-note' | 'prioritize';

function App() {
  const [currentView, setCurrentView] = useState<View>('notes');
  const [selectedNote, setSelectedNote] = useState<Note | null>(null);
  const [showAddNote, setShowAddNote] = useState(false);
  const [showVoiceSheet, setShowVoiceSheet] = useState(false);
  const [showTagsDrawer, setShowTagsDrawer] = useState(false);
  const [selectedTag, setSelectedTag] = useState<string | null>(null);
  const [showActionMenu, setShowActionMenu] = useState(false);
  const [showDictateSheet, setShowDictateSheet] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [notes, setNotes] = useState<Note[]>([
    {
      id: '1',
      date: '20 APR',
      title: 'Exploration Ideas',
      tags: ['Design', 'Productivity'],
      preview: 'Ticket App\nTravel Website\nDigital Marketing Website...',
      content: 'Ticket App\nTravel Website\nDigital Marketing Website\n\nThese are some ideas for upcoming projects to explore.',
      lastModified: '20 April 2024, 10:30 AM',
    },
    {
      id: '2',
      date: '19 APR',
      title: 'Database Systems Week 4',
      tags: ['College', 'Lecture'],
      preview: 'Normalization is the process of ordering basic data structures to ensure that the basic data created is of good quality.',
      content: 'Normalization\n\nNormalization is the process of ordering basic data structures to ensure that the basic data created is of good quality. Used to minimize data redundancy and data inconsistencies.\n\nNormalization stage starts from the lightest stage (1NF) to the strictest (5NF). Usually only up to the 3NF or BCNF level as they are sufficient to produce good quality tables.',
      lastModified: '19 April 2024, 8:39 PM',
    },
    {
      id: '3',
      date: '18 APR',
      title: 'Grocery List',
      tags: ['Shopping', 'List'],
      preview: "Today's shopping list:\nCereal\nShampoo\nToothpaste\nApple\nCup Noodles...",
      content: "Today's shopping list:\n\n• Cereal\n• Shampoo\n• Toothpaste\n• Apple\n• Cup Noodles",
      lastModified: '18 April 2024, 3:15 PM',
    },
    {
      id: '4',
      date: '19 APR',
      title: 'Daily Tasks',
      tags: ['Productivity', 'Daily'],
      preview: 'House chores\n2 km run\nRead a book\nLaundry',
      content: 'Daily Tasks:\n\n○ House chores\n○ 2 km run\n○ Read a book\n○ Laundry',
      lastModified: '19 April 2024, 7:00 AM',
    },
    {
      id: '5',
      date: '18 APR',
      title: 'Interaction Design Week 4',
      tags: ['College', 'Lecture'],
      preview: 'Qualitative research involves collecting and analyzing non-numerical data...',
      content: 'Qualitative research involves collecting and analyzing non-numerical data to understand concepts, opinions, or experiences. It is used to gather in-depth insights into a problem or generate new ideas for research.',
      lastModified: '18 April 2024, 2:45 PM',
    },
    {
      id: '6',
      date: '18 APR',
      title: 'Business Process Remodelling Week 3',
      tags: ['College', 'Lecture'],
      preview: 'Process analysis involves examining business processes...',
      content: 'Process analysis involves examining business processes to identify areas for improvement and optimization. Key methodologies include value stream mapping and process flowcharting.',
      lastModified: '18 April 2024, 11:20 AM',
    },
  ]);

  // Get all unique tags from notes
  const allTags = Array.from(
    new Set(notes.flatMap(note => note.tags || []))
  ).sort();

  // Filter notes by selected tag
  const filteredNotes = selectedTag
    ? notes.filter(note => note.tags?.includes(selectedTag))
    : notes;

  const handleNoteClick = (note: Note) => {
    setSelectedNote(note);
    setCurrentView('note-detail');
  };

  const handleBack = () => {
    setCurrentView('notes');
    setSelectedNote(null);
  };

  const handleAddNote = (noteData: { title: string; content: string; tags: string[] }) => {
    const newNote: Note = {
      id: Date.now().toString(),
      date: new Date().toLocaleDateString('en-US', { day: 'numeric', month: 'short' }).toUpperCase(),
      title: noteData.title,
      tags: noteData.tags,
      preview: noteData.content.substring(0, 100) + '...',
      content: noteData.content,
      lastModified: new Date().toLocaleString('en-US', { 
        day: 'numeric', 
        month: 'long', 
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      }),
    };
    setNotes([newNote, ...notes]);
    setShowAddNote(false);
  };

  const handleSaveTranscription = (text: string) => {
    const newNote: Note = {
      id: Date.now().toString(),
      date: new Date().toLocaleDateString('en-US', { day: 'numeric', month: 'short' }).toUpperCase(),
      title: 'Voice Note',
      tags: ['Voice', 'Transcription'],
      preview: text.substring(0, 100) + '...',
      content: text,
      lastModified: new Date().toLocaleString('en-US', { 
        day: 'numeric', 
        month: 'long', 
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      }),
    };
    setNotes([newNote, ...notes]);
  };

  const handleDictate = () => {
    setShowActionMenu(false);
    setShowDictateSheet(true);
  };

  const handleScan = () => {
    setShowActionMenu(false);
    // TODO: Implement camera functionality
    alert('Camera scan feature coming soon!');
  };

  const handleWrite = () => {
    setShowActionMenu(false);
    setCurrentView('blank-note');
  };

  const handleTogglePromote = (noteId: string) => {
    setNotes(notes.map(note => 
      note.id === noteId 
        ? { ...note, promoted: !note.promoted }
        : note
    ));
    
    // Also update selectedNote if it matches the noteId
    if (selectedNote && selectedNote.id === noteId) {
      setSelectedNote({ ...selectedNote, promoted: !selectedNote.promoted });
    }
  };

  const handleUpdatePriority = (noteId: string, priority: number) => {
    setNotes(notes.map(note => 
      note.id === noteId 
        ? { ...note, priority }
        : note
    ));
  };

  return (
    <div className="max-w-md mx-auto bg-gray-50 relative">
      {/* Main Content */}
      {currentView === 'notes' && (
        <NotesListView
          notes={filteredNotes}
          onNoteClick={handleNoteClick}
          onAddNote={() => setShowAddNote(true)}
          onSettingsClick={() => setCurrentView('settings')}
          selectedTag={selectedTag}
          onTitleClick={() => setShowTagsDrawer(true)}
          onTogglePromote={handleTogglePromote}
        />
      )}

      {currentView === 'note-detail' && selectedNote && (
        <NoteDetailView 
          note={selectedNote} 
          onBack={handleBack}
          onSettingsClick={() => setCurrentView('settings')}
          onTogglePromote={handleTogglePromote}
        />
      )}

      {currentView === 'settings' && (
        <SettingsView 
          onBack={() => setCurrentView('notes')} 
          onPrioritizeClick={() => setCurrentView('prioritize')}
        />
      )}

      {currentView === 'blank-note' && (
        <BlankNoteEditor
          onBack={() => setCurrentView('notes')}
          onSave={handleAddNote}
        />
      )}

      {currentView === 'prioritize' && (
        <PrioritizeView
          onBack={() => setCurrentView('notes')}
          notes={notes}
          onUpdatePriority={handleUpdatePriority}
        />
      )}

      {/* Floating Action Button */}
      {currentView !== 'settings' && currentView !== 'note-detail' && currentView !== 'blank-note' && !showActionMenu && (
        <button
          onClick={() => setShowActionMenu(true)}
          className="fixed bottom-6 right-6 z-50 w-14 h-14 bg-black text-white rounded-full shadow-lg hover:shadow-xl transition-all hover:scale-110 flex items-center justify-center"
        >
          <Plus className="w-6 h-6" />
        </button>
      )}

      {/* Add Note Dialog */}
      <AddNoteDialog
        open={showAddNote}
        onClose={() => setShowAddNote(false)}
        onSave={handleAddNote}
      />

      {/* Voice Translation Sheet */}
      <VoiceTranslationSheet
        open={showVoiceSheet}
        onClose={() => setShowVoiceSheet(false)}
        onSaveTranscription={handleSaveTranscription}
      />

      {/* Tags Drawer */}
      <TagsDrawer
        open={showTagsDrawer}
        onClose={() => setShowTagsDrawer(false)}
        tags={allTags}
        selectedTag={selectedTag}
        onTagSelect={setSelectedTag}
      />

      {/* Action Menu */}
      <ActionMenu
        open={showActionMenu}
        onClose={() => setShowActionMenu(false)}
        onDictate={handleDictate}
        onScan={handleScan}
        onWrite={handleWrite}
        isRecording={isRecording}
      />

      {/* Dictate Sheet */}
      <DictateSheet
        open={showDictateSheet}
        onClose={() => setShowDictateSheet(false)}
        onSaveTranscription={handleSaveTranscription}
      />
    </div>
  );
}

export default App;